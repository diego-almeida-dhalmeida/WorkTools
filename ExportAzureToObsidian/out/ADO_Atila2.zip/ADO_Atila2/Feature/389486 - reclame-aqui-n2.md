---
id: "WI-389486"
title: "Reclame Aqui - N2"
type: "Feature"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: ""
created: "2024-06-25T14:02:19.293Z"
changed: "2025-01-21T12:45:50.8Z"
---
# WI-389486 - Reclame Aqui - N2

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/389486](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/389486)

## 1. Identificação

- **ID/Ref:** WI-389486
- **Tipo:** Feature
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

_Sem descrição no ADO._
