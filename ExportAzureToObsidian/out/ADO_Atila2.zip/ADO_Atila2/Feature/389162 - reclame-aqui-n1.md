---
id: "WI-389162"
title: "Reclame Aqui - N1"
type: "Feature"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 6 - Relacionamento Melhorias"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-06-24T17:50:10.397Z"
changed: "2025-01-21T12:45:50.8Z"
---
# WI-389162 - Reclame Aqui - N1

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/389162](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/389162)

## 1. Identificação

- **ID/Ref:** WI-389162
- **Tipo:** Feature
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

_Sem descrição no ADO._
