---
id: "WI-495717"
title: "[Relacionamento] - Ações para os alunos (Retabilização)"
type: "Feature"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 05-2025-Relacionamento"
assignedTo: ""
created: "2025-06-03T18:20:53.053Z"
changed: "2025-06-06T21:16:52.01Z"
---
# WI-495717 - [Relacionamento] - Ações para os alunos (Retabilização)

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/495717](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/495717)

## 1. Identificação

- **ID/Ref:** WI-495717
- **Tipo:** Feature
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

_Sem descrição no ADO._
