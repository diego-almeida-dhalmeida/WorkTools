---
id: "WI-449289"
title: "Relatórios e Dashs Ouvidoria"
type: "User Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\SPRINT FINAL"
assignedTo: ""
created: "2025-01-15T17:15:55.39Z"
changed: "2025-03-25T17:36:10.38Z"
---
# WI-449289 - Relatórios e Dashs Ouvidoria

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/449289](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/449289)

## 1. Identificação

- **ID/Ref:** WI-449289
- **Tipo:** User Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

**Eu, como**  atendente, supervisor e coordenador 

**Quero**  gerenciar os casos abertos na plataforma Salesforce a partir de requerimentos abertos no SIA e que estão em atendimento. 

**Para  **garantir a qualidade no processo de atendimento e mapear melhorias no fluxo. 

  


**RN01 - Visão do tempo de abertura de Caso**

**  
**

Visualização nos relatórios/dashs de quanto tempo um caso está aberto, bem como a sua data de fechamento e o tempo que falta para chegar na data/hora precista no SLA.** **

  


**RN02 - Visão de casos por proprietário**

  


Visualicação de casos criados, agrupados por agente e fila. 

  


**RN03 - Visão do tempo do caso por status  ** 

  


Visualização de quanto tempo um caso passou em determinado status.
