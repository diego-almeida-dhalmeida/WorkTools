---
id: "WI-476186"
title: "[Telefonia/Captação] - Abertura de caso para o atendente de Captação"
type: "User Story"
state: "Active"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Rodolfo Rodrigo da Silva"
created: "2025-04-04T19:53:01.59Z"
changed: "2025-09-02T12:37:48.32Z"
---
# WI-476186 - [Telefonia/Captação] - Abertura de caso para o atendente de Captação

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/476186](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/476186)

## 1. Identificação

- **ID/Ref:** WI-476186
- **Tipo:** User Story
- **Status:** Active


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

**Critério de aceite**

**Dado que   **eu entro no sistema de captação como atendente ATL - Atendimento

**Quando** receber uma ligação no conector Avaya

**Então** , o caso Captação - Voz deverá abrir automaticamente para o operador na tela de atendimento captação voz


## 9. Descrição (Abaixo vem do Azure DevOps)

****

**Eu como**  atendente ATL - Atendimento,

**Quero  **ter imediatamente após o atendimento da chamada do candidato, o pop-up da "tela" do caso de captação voz para aquele atendimento.

**Para  **agilizar o registro do atendimento de captação.

**  
  
**

**RN01 -  **Os casos de captação voz deverão ser "popados" no aplicativo de vendas (Assim como telefonia)  


 

**Obs:** O atendimento Avaya já existe.
