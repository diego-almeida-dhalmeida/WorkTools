---
id: "WI-390101"
title: "Relatórios e Dashs de casos N2 no Salesforce"
type: "User Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Andre Luiz de Paula Bezerra"
created: "2024-06-26T17:42:17.367Z"
changed: "2024-11-05T20:18:02.79Z"
---
# WI-390101 - Relatórios e Dashs de casos N2 no Salesforce

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/390101](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/390101)

## 1. Identificação

- **ID/Ref:** WI-390101
- **Tipo:** User Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

**Eu, como**  atendente, supervisor e coordenador 

**Quero**  gerenciar os casos abertos na plataforma Salesforce a partir de reclamações aberta no ReclameAqui e que estão no nível 2 de atendimento. 

**Para  **garantir a qualidade no processo de atendimento e mapear melhorias no fluxo. 

  


**RN01 - Visão do tempo de abertura de Caso**

**  
**

Visualização nos relatórios/dashs de quanto tempo um caso está aberto, bem como a sua data de fechamento e o tempo que falta para chegar na data/hora precista no SLA.** **

  


**RN02 - Visão de casos por proprietário**

  


Visualicação de casos criados, agrupados por agente e fila. 

  


**RN03 - Visão do tempo do caso por status  ** 

  


Visualização de quanto tempo um caso passou em determinado status.
