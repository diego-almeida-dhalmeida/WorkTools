---
id: "WI-361723"
title: "[Telefonia] Ativação na integração da Captação do CTI URA com Salesforce - RECEPTIVO"
type: "User Story"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-04-02T15:10:45.187Z"
changed: "2025-01-15T20:08:52.83Z"
---
# WI-361723 - [Telefonia] Ativação na integração da Captação do CTI URA com Salesforce - RECEPTIVO

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/361723](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/361723)

## 1. Identificação

- **ID/Ref:** WI-361723
- **Tipo:** User Story
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

O mesmo da história referenciada.


## 9. Descrição (Abaixo vem do Azure DevOps)

Essa história é somente uma referência da história: [#339484](https://dev.azure.com/ArquiteturaEstacio/Atila%202.0/_workitems/edit/339484/)
