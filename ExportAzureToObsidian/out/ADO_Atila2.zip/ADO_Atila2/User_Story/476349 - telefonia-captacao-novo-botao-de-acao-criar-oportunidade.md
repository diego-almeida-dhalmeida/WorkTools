---
id: "WI-476349"
title: "[Telefonia/Captação] - Novo botão de Ação Criar Oportunidade"
type: "User Story"
state: "Active"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: ""
created: "2025-04-07T10:54:17.55Z"
changed: "2025-09-02T12:39:24.477Z"
---
# WI-476349 - [Telefonia/Captação] - Novo botão de Ação Criar Oportunidade

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/476349](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/476349)

## 1. Identificação

- **ID/Ref:** WI-476349
- **Tipo:** User Story
- **Status:** Active


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

**Critério de aceite  **01****

**Dado que  **estou em atendimento com o candidato

**Quando  **houver a necessidade de criação de uma nova Oportunidade 

**Então** , ao clicar no botão de Criar Oportunidade, a tela de cadastro de Opotunidade deve aparecer dentro do Caso de atendimento Captação-Voz.

**  
**

**  
**

**Critério de aceite 02**

**Dado que**** ** Esou gerando uma nova oportunidade

**Quando**  a oportunidade for criada

**Então** , deverá haver uma relação automatica da Oportunidade com o caso.


## 9. Descrição (Abaixo vem do Azure DevOps)

**Eu como** atendente ATL - Atendimento, 

**Quero**  ter acesso a um botão de ação no canto superior direito da tela do Caso de captação voz,

**Para  **a criação de Oportunidade

 

**RN01****-  **Esse botão vai abrir a criação de Oportunidade.

**RN02  ****-** A oportunidade deve estar vinculada a conta do caso

**RN03  ****-  **Deve haver uma interface com o objeto Oportunidade, trazendo o campo de preenchimento de nova Oportunidade  
  
Obs.: O botão de oportunidade estará dentro do Caso de atendimento Captação voz

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/bd50c372-7554-44c6-b353-9147be6e4cb2?fileName=image.png)
