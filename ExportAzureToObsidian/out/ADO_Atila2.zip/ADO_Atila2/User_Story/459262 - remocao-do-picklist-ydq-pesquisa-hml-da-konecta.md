---
id: "WI-459262"
title: "Remoção do Picklist \"YDQ_Pesquisa_HML\" da Konecta"
type: "User Story"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2025-Relacionamento"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2025-02-13T21:28:37.167Z"
changed: "2025-04-14T22:12:36.77Z"
---
# WI-459262 - Remoção do Picklist "YDQ_Pesquisa_HML" da Konecta

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/459262](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/459262)

## 1. Identificação

- **ID/Ref:** WI-459262
- **Tipo:** User Story
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

...


## 9. Descrição (Abaixo vem do Azure DevOps)

**Eu como** operador do Call Center com perfil Atendente Voz - Aluno 

**Quero** que a opção "YDQ_Pesquisa_HML" seja removida da Picklist de transferência no conector da Avaya 

**Com o objetivo de** organizar a listagem de opções da matriz de transferência de produção 

  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/617ca398-fb7c-4693-aa6b-ec893304a8e2?fileName=image.png)
