---
id: "WI-443720"
title: "[Telefonia] Encaminhamento - Remover crítica da modal do caso do operador do call center apos encaminhamento para o Backoffice"
type: "User Story"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2024-CoERelac-2 ªOndaTelefonia"
assignedTo: "Caroline Rodrigues da Silva"
created: "2024-12-17T18:53:11.07Z"
changed: "2025-03-21T14:46:24.883Z"
---
# WI-443720 - [Telefonia] Encaminhamento - Remover crítica da modal do caso do operador do call center apos encaminhamento para o Backoffice

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/443720](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/443720)

## 1. Identificação

- **ID/Ref:** WI-443720
- **Tipo:** User Story
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

**Dado que** o caso foi encaminhado para o Backoffice,

**Quando** o encaminhamento for concluído,  
**Então** o caso deve ficar livre para ser fechado no X da aba.


## 9. Descrição (Abaixo vem do Azure DevOps)

******Eu como**  operador do call center (Perfil Atendente Voz - Aluno, ou Atendente-Aluno)  


**Quero**  na tela de tarefa do caso, que o caso tenha a crítica removida, a crítica do modal após encaminhamento do caso para o backoffice  
**Para que** eu consiga resolver os caso de atendimento
