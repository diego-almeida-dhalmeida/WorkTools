---
id: "WI-507031"
title: "Ajuste de perfil COE_GestaoDeAcesso para alteração no objeto usuário"
type: "User Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 08-2025-Relacionamento"
assignedTo: ""
created: "2025-07-04T13:31:46.4Z"
changed: "2025-07-04T13:35:44.687Z"
---
# WI-507031 - Ajuste de perfil COE_GestaoDeAcesso para alteração no objeto usuário

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/507031](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/507031)

## 1. Identificação

- **ID/Ref:** WI-507031
- **Tipo:** User Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

**Eu como**  usuário com o perfil __COE_GestaoDeAcesso

**Quero  **ter acesso aos campos do objeto usuário  


**Para que**  eu possa gerenciar os acessos dos outros usuários corretamente.
