---
id: "WI-464328"
title: "[Telefonia] - Disparo de e-mail automático na finalização de caso do backoffice"
type: "User Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2025-02-27T12:58:23.197Z"
changed: "2025-08-08T14:59:19.553Z"
---
# WI-464328 - [Telefonia] - Disparo de e-mail automático na finalização de caso do backoffice

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/464328](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/464328)

## 1. Identificação

- **ID/Ref:** WI-464328
- **Tipo:** User Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

No que fechar o caso informar ao aluno o status de resolução do problema.
