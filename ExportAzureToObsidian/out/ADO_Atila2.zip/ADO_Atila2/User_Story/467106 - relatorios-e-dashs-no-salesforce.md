---
id: "WI-467106"
title: "Relatórios e Dashs no Salesforce"
type: "User Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Andre Luiz de Paula Bezerra"
created: "2025-03-12T18:45:32.623Z"
changed: "2025-03-12T19:22:49.08Z"
---
# WI-467106 - Relatórios e Dashs no Salesforce

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/467106](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/467106)

## 1. Identificação

- **ID/Ref:** WI-467106
- **Tipo:** User Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

**Eu, como**  atendente, supervisor e coordenador 

**Quero**  gerenciar os casos abertos na plataforma Salesforce a partir de requerimentos registrados no SIA. 

**Para  **garantir a qualidade no processo de atendimento e mapear melhorias no fluxo. 

  


**RN01 - Visão do tempo de abertura de Caso**

**  
**

Visualização nos relatórios/dashs de quanto tempo um caso está aberto, bem como a sua data de fechamento e o tempo que falta para chegar na data/hora precista no SLA.** **

  


**RN02 - Visão de casos por proprietário**

  


Visualicação de casos criados, agrupados por agente e fila. 

  


**RN03 - Visão do tempo do caso por status  ** 

  


Visualização de quanto tempo um caso passou em determinado status.
