---
id: "WI-476347"
title: "[Telefonia/Captação] - Adicionar o botão de Ação Pesquisar candidato"
type: "User Story"
state: "Active"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Adriano Meireles Santos"
created: "2025-04-07T10:29:11.027Z"
changed: "2025-08-08T14:59:19.553Z"
---
# WI-476347 - [Telefonia/Captação] - Adicionar o botão de Ação Pesquisar candidato

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/476347](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/476347)

## 1. Identificação

- **ID/Ref:** WI-476347
- **Tipo:** User Story
- **Status:** Active


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

**Critério de aceite**

**Dado que  **estou em atendimento.

**Quando  **houver a necessidade de pesquisa

**Então** , ao clicar no botão de pesquisar candidato, os parâmetros de busca e a tela de pesquisa, devem aparecer na tela do Caso de atendimento Captação-Voz.


## 9. Descrição (Abaixo vem do Azure DevOps)

**Eu como** atendente ATL - Atendimento, 

**Quero**   ter acesso a um botão de ação no canto superior direito da tela do Caso de captação voz, para pesquisa de candidato.

**Para** o caso de uma nova necessidade de pesquisa durante o atendimento.

**  
**

**RN01****-** Deve haver uma interface com o Objeto Pesquisa Candidato do Salescloud.  
(Verificar a adaptação do botão para a tela de atendimento Captação voz)

Qual deve ser o comportamento após o resultado da pesquisa? 

Tem alguma ação dentro do componente ou é apenas para consulta?

  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/64f00668-2dcd-4dfc-8d74-2dc274164c69?fileName=image.png)
