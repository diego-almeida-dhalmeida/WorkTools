---
id: "WI-417953"
title: "[Telefonia] Cascata - Perguntas com dado no Salesforce devem ser automatizadas"
type: "User Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-09-19T18:29:54.44Z"
changed: "2024-11-27T18:00:34.43Z"
---
# WI-417953 - [Telefonia] Cascata - Perguntas com dado no Salesforce devem ser automatizadas

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417953](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417953)

## 1. Identificação

- **ID/Ref:** WI-417953
- **Tipo:** User Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Nos fluxos descritos, quando uma pergunta puder ser automatizada (por de um dado que temos internamente no salesforce), não deve aparecer para o atendente e deve ser preenchida automaticamente. Caso ocorra algum erro na hora de preencher a pergunta, a pergunta deve aparecer para o atendente preencher manualmente.
