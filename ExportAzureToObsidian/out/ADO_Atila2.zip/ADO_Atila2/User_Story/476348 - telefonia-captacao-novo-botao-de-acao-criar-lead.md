---
id: "WI-476348"
title: "[Telefonia/Captação] - Novo botão de Ação Criar Lead"
type: "User Story"
state: "Active"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: ""
created: "2025-04-07T10:45:06.04Z"
changed: "2025-08-05T17:24:19.967Z"
---
# WI-476348 - [Telefonia/Captação] - Novo botão de Ação Criar Lead

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/476348](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/476348)

## 1. Identificação

- **ID/Ref:** WI-476348
- **Tipo:** User Story
- **Status:** Active


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

**Critério de aceite**

**Dado que  **estou em atendimento com o candidato

**Quando  **houver a necessidade de criação de um novo Lead

**Então** , ao clicar no botão de Criar Lead, a tela de cadastro de Lead deve aparecer dentro do Caso de atendimento Captação-Voz.


## 9. Descrição (Abaixo vem do Azure DevOps)

**Eu, como** atendente ATL - Atendimento, 

**Quero**   ter acesso a um botão de ação no canto superior direito da tela do Caso de captação voz,

**Para** criação de Lead

 

**RN01****-** Esse botão vai abrir a criação de Lead.

**RN02  ****-  **Deve haver uma interface com o objeto lead, trazendo o campo de preenchimento de novo lead.  
Obs.: O lead é associado automaticamente ao caso após a criação.  
  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/58f0485e-44b7-4d29-85c7-bc04cc829de2?fileName=image.png)
