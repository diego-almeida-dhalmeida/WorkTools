---
id: "WI-513570"
title: "Cadastro de nova tabulação"
type: "User Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 08-2025-Relacionamento"
assignedTo: ""
created: "2025-07-18T20:33:21.65Z"
changed: "2025-08-08T14:59:19.553Z"
---
# WI-513570 - Cadastro de nova tabulação

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/513570](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/513570)

## 1. Identificação

- **ID/Ref:** WI-513570
- **Tipo:** User Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

_Sem descrição no ADO._
