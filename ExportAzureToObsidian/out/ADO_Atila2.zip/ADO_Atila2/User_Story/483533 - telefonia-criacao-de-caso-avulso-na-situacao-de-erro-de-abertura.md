---
id: "WI-483533"
title: "[Telefonia] - Criação de caso avulso na situação de erro de abertura"
type: "User Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2025-04-29T14:31:21.377Z"
changed: "2025-04-29T20:04:08.3Z"
---
# WI-483533 - [Telefonia] - Criação de caso avulso na situação de erro de abertura

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/483533](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/483533)

## 1. Identificação

- **ID/Ref:** WI-483533
- **Tipo:** User Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

**Eu como**  operador do Call Center com perfil Atendente voz - Aluno,

**Quero** poder criar manualmente um caso avulso no Salesforce quando uma ligação for recebida da URA e não gerar automaticamente um caso, 

**Para** que nenhuma interação importante com o cliente seja perdida e eu possa registrar e acompanhar a solicitação adequadamente. 

  


****

**R1:**  O botão ou opção "Criar Caso Avulso" só ficará habilitado se houver uma chamada em curso ou associada ao atendente.  
  


**R2:**  A criação de casos avulsos só é permitida durante a chamada, caso a chamada caia, ou tenha sido finalizada o caso não poderá ser aberto.
