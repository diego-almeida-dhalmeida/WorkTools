---
id: "WI-533413"
title: "Marcações de Callback"
type: "User Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: ""
created: "2025-09-09T14:12:40.82Z"
changed: "2025-09-15T19:32:58.643Z"
---
# WI-533413 - Marcações de Callback

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/533413](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/533413)

## 1. Identificação

- **ID/Ref:** WI-533413
- **Tipo:** User Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

**Eu como** Gestor aluno  


**Gostaria que** fosse criado um botão de CallBack  


**Para quando** uma ligação for desligada pelo cliente   


Seja possível que o operador retorne a ligação para o aluno  


  


  


**RN1**  


Deve ser exibido um botão de call-back quando a ligação for desligada pelo cliente e assim reestabelecendo o atendimento com o Aluno  


Validar possibilidade de exibir opção de call-back em modal semelhante a tabulação.  
  


**RN2**  


Não deve ocorrer o fechamento automático do caso quando houver desconexão  


  


**RN3**  


Não deve exibir o modal de tabulação  


  


**RN4**  


Ao reestabelecer a ligação com o aluno as marcações de Callback realizado, sucesso e insucesso sejam registrados no caso.
