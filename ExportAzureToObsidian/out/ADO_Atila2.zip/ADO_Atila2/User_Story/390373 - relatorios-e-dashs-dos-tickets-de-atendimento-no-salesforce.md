---
id: "WI-390373"
title: "Relatórios e Dashs dos tickets de atendimento no Salesforce"
type: "User Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Andre Luiz de Paula Bezerra"
created: "2024-06-27T14:18:29.063Z"
changed: "2024-11-05T20:18:02.79Z"
---
# WI-390373 - Relatórios e Dashs dos tickets de atendimento no Salesforce

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/390373](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/390373)

## 1. Identificação

- **ID/Ref:** WI-390373
- **Tipo:** User Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

_Sem descrição no ADO._
