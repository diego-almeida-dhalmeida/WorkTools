---
id: "WI-489671"
title: "[Relacionamento] Atendimento Online - Automático (EDD - Autosserviços)"
type: "User Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Adriano Meireles Santos"
created: "2025-05-19T14:17:23.097Z"
changed: "2025-08-08T14:59:19.553Z"
---
# WI-489671 - [Relacionamento] Atendimento Online - Automático (EDD - Autosserviços)

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/489671](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/489671)

## 1. Identificação

- **ID/Ref:** WI-489671
- **Tipo:** User Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

Critério de Aceite 01  
Dado que o Aluno selecionou um Serviço através de um Canal de Atendimento 

Quando o caso de autoatendimento for finalizado 

Então, o Caso deverá ser registrado automaticamente no Salesforce.


## 9. Descrição (Abaixo vem do Azure DevOps)

Eu como Aluno 

Quero que que minha solicitação seja registrada no Salesforce da Yduq 

Para que fique registrado o atendimento com o Serviço selecionado. 

 

RN 01 O serviço a ser registrado no Caso, deverá ser aquele selecionado pelo aluno dentro do canal de atendimento utilizado
