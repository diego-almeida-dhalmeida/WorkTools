---
id: "WI-444385"
title: "[Telefonia] Envio de e-mail - Visualização do assunto, corpo e anexos do e-mail enviado pelo operador"
type: "User Story"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 01-2025-Relacionamento"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-12-19T23:35:06.42Z"
changed: "2025-03-07T18:05:26.723Z"
---
# WI-444385 - [Telefonia] Envio de e-mail - Visualização do assunto, corpo e anexos do e-mail enviado pelo operador

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/444385](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/444385)

## 1. Identificação

- **ID/Ref:** WI-444385
- **Tipo:** User Story
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

**Cenário 01 - Visualização do e-mail enviado**

**Dado que** estou na tabela de histórico de e-mails,  


**Quando** clico no botão para visualizar a mensagem completa,  


**Então** devo ser redirecionado para uma tela que exibe a mensagem completa que foi enviada para o aluno, com a possibilidade de consultar os anexos dessa mensagem.


## 9. Descrição (Abaixo vem do Azure DevOps)

**Eu como** operador do call center (Perfil Atendente Voz - Aluno, ou Atendente-Aluno) 

**Quero,** na área de histórico de e-mail, clicar no título de um e-mail enviado pelos operadores e visualizar a mensagem enviada inclusive com seus anexos. 

**Para** poder ter a consulta das informações enviadas para os alunos em casos de verificação do conteúdo.
