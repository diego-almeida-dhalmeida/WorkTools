---
id: "WI-369626"
title: "Telefonia - Botão de \"Encerrar Caso\" na tela de caso"
type: "Improvement"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-04-25T02:21:16.87Z"
changed: "2025-02-18T21:25:51.263Z"
---
# WI-369626 - Telefonia - Botão de "Encerrar Caso" na tela de caso

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/369626](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/369626)

## 1. Identificação

- **ID/Ref:** WI-369626
- **Tipo:** Improvement
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Durante o atendimento humano está aparecendo um botão de "Encerrar Caso" na tela de caso.  
Resultado esperado: única forma dos atendentes de whatsapp e chat encerrarem o atendimento ser através do botão "Encerrar atendimento" na tela de atendimento (Messaging Session ou Chat Transcript) 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/94cb144e-48be-409d-964c-91d8b78cbe17?fileName=image.png)
