---
id: "WI-445070"
title: "Incluir a coluna \"Status Backoffice\" nas listas dos operadores"
type: "Improvement"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 03-2025-Relacionamento"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-12-27T16:23:45.07Z"
changed: "2025-02-27T23:35:45.143Z"
---
# WI-445070 - Incluir a coluna "Status Backoffice" nas listas dos operadores

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/445070](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/445070)

## 1. Identificação

- **ID/Ref:** WI-445070
- **Tipo:** Improvement
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

...


## 9. Descrição (Abaixo vem do Azure DevOps)

Incluir a coluna, referente ao campo "Status Backoffice" nas listas:  
  
Meus Casos 

Meus Casos em Andamento 

Todos os Meus Casos 

BO SAC Konecta

BO Retenção Elo  


  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/555186ed-3889-4361-9757-a102ca24a285?fileName=image.png)
