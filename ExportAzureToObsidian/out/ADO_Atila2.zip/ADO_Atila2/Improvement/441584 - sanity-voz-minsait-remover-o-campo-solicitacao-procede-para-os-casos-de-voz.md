---
id: "WI-441584"
title: "[SANITY | Voz] Minsait - Remover o campo \"Solicitação Procede\" para os casos de voz"
type: "Improvement"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 01-2025-Relacionamento"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-12-07T13:46:53.75Z"
changed: "2025-03-07T18:04:11.217Z"
---
# WI-441584 - [SANITY | Voz] Minsait - Remover o campo "Solicitação Procede" para os casos de voz

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/441584](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/441584)

## 1. Identificação

- **ID/Ref:** WI-441584
- **Tipo:** Improvement
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Retirar o campo de "Solicitação Procede" para os caso de "SAC - Voz":

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/71744df3-c05b-45dc-8214-c7aee84c0339?fileName=image.png)
