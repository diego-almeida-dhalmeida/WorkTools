---
id: "WI-437158"
title: "[SANITY | VOZ] Minsait - Dashboard de atendimento não está encontrando as informações da fila de voz"
type: "Improvement"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2024-CoERelac-2 ªOndaTelefonia"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-11-24T01:37:44.08Z"
changed: "2025-03-07T18:09:12.603Z"
---
# WI-437158 - [SANITY | VOZ] Minsait - Dashboard de atendimento não está encontrando as informações da fila de voz

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/437158](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/437158)

## 1. Identificação

- **ID/Ref:** WI-437158
- **Tipo:** Improvement
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Dashboard de atendimento não está encontrando as informações da fila de Voz:  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/1e33944d-ff05-422c-9543-ad15adfd69d2?fileName=image.png)  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/c5402775-aafc-4a30-8ece-25334f1d1f5e?fileName=image.png)  


  


Link: 

<https://yduqs2020--uat3.sandbox.lightning.force.com/lightning/r/sObject/01Z7V000000skv3UAA/view?queryScope=userFolders>  


  


Quando filtramos pela Origem do Caso os resultados aparecem:  
  
![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/dc9db82e-362b-48b1-b552-baea7fcd4fa0?fileName=image.png)
