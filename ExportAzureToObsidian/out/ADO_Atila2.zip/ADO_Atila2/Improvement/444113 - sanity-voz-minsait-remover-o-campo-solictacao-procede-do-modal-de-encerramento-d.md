---
id: "WI-444113"
title: "[SANITY | Voz] Minsait - Remover o campo Solictação Procede do Modal de encerramento de SAC- Voz"
type: "Improvement"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 01-2025-Relacionamento"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-12-18T23:00:48.62Z"
changed: "2025-03-10T16:54:00.383Z"
---
# WI-444113 - [SANITY | Voz] Minsait - Remover o campo Solictação Procede do Modal de encerramento de SAC- Voz

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/444113](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/444113)

## 1. Identificação

- **ID/Ref:** WI-444113
- **Tipo:** Improvement
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

No modal de encerramento do caso, remover o campo "Solicitação Procede" para os casos do tipo SAC-Voz, Retenção - Voz e Captação - Voz;

  
![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/8799e6fd-24cd-4e64-82d6-db5a95d75090?fileName=image.png)
