---
id: "WI-486642"
title: "[Telefonia] - Alterar status do caso para \"aberto\" no momento do envio da consulta"
type: "Improvement"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Willames Izaias Santos da Silva"
created: "2025-05-08T18:48:31.74Z"
changed: "2025-06-13T13:38:59.563Z"
---
# WI-486642 - [Telefonia] - Alterar status do caso para "aberto" no momento do envio da consulta

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/486642](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/486642)

## 1. Identificação

- **ID/Ref:** WI-486642
- **Tipo:** Improvement
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

No momento de uma conferência, o status do caso pai está alterado para "Transferência". Porém, por conta dos ajustes nas questões de transferência de casos, pode ocorrer uma situação de recusa de transferência e o caso pai ficar com um status incorreto.   


  
Sendo assim, no momento de uma consulta o caso deve ficar com status Aberto. 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/f19146e2-2089-4c8c-a256-47e7ce567617?fileName=image.png)
