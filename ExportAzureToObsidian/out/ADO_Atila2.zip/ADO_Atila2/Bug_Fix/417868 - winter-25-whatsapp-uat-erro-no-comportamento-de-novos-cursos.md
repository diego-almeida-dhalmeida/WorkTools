---
id: "WI-417868"
title: "[Winter 25 - WhatsApp UAT] Erro no comportamento de novos cursos"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 01-2024-CoERelac"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-09-19T17:54:46.46Z"
changed: "2024-10-18T02:27:45.477Z"
---
# WI-417868 - [Winter 25 - WhatsApp UAT] Erro no comportamento de novos cursos

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417868](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417868)

## 1. Identificação

- **ID/Ref:** WI-417868
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Ao escolher a opção no BOT de novos cursos, aluno está sendo transbordado automaticamente (quando atendente está online). Deveria abrir a faq/texto registrado e marcar no caso a opção de novos cursos. 

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/b39b8716-927e-4cb6-ac77-cb1eefcbd7cb?fileName=image.png)  


  


  


comportamento desejado: 

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/c468384a-f98d-4872-b926-6437be9608a3?fileName=image.png)
