---
id: "WI-522382"
title: "[Telefonia] Tempos de atendimento Negativos"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-08-11T20:19:10.477Z"
changed: "2025-08-28T13:34:16.4Z"
---
# WI-522382 - [Telefonia] Tempos de atendimento Negativos

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/522382](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/522382)

## 1. Identificação

- **ID/Ref:** WI-522382
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Ao realizar teste de transferência para EPS Elo para atendimento de retenção as marcações de tempos de atendimento estão negativos. 

  


Case: 08153713

  
  
![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/189d3a5d-7006-4d4a-a76e-1816e8d3d945?fileName=image.png)  


  


  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/05b159a8-a691-4118-a6ee-acc54e90073f?fileName=image.png)
