---
id: "WI-523826"
title: "[Telefonia] Marcação de transferência > 0"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-08-13T22:12:11.11Z"
changed: "2025-08-27T13:59:54.37Z"
---
# WI-523826 - [Telefonia] Marcação de transferência > 0

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523826](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523826)

## 1. Identificação

- **ID/Ref:** WI-523826
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Marcação de transferência esta > 0 em ligações que chegam para o humano e não ocorrem transferência e consultas a outros.  
  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/10913d42-a5c4-4026-9be6-deded5dad8d1?fileName=image.png)
