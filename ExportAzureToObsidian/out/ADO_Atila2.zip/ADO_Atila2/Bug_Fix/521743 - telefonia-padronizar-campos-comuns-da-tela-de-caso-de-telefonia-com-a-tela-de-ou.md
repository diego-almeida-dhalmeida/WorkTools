---
id: "WI-521743"
title: "[Telefonia] - Padronizar campos comuns da tela de caso de Telefonia com a tela de outros canais"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Guilherme Dionizio Brandao"
created: "2025-08-08T20:57:37.723Z"
changed: "2025-08-27T13:59:54.37Z"
---
# WI-521743 - [Telefonia] - Padronizar campos comuns da tela de caso de Telefonia com a tela de outros canais

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/521743](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/521743)

## 1. Identificação

- **ID/Ref:** WI-521743
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Padronizar os campos comuns da tela de caso (caso, caso filho e caso avulso) com a tela de caso dos canais Whatapp e Chat. No exemplo abaixo, o Status do caso está como Aberta e nos outros canais é Novo.  
![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/2a81e570-8e9b-4e34-b27c-168d4003ce8f?fileName=image.png)
