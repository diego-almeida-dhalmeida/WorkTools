---
id: "WI-482108"
title: "[Telefonia] - Caso de Whatsapp Ativo sendo criado como SAC-VOZ"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Renan Robson Lima Carneiro"
created: "2025-04-24T17:53:53.37Z"
changed: "2025-05-21T22:24:05.063Z"
---
# WI-482108 - [Telefonia] - Caso de Whatsapp Ativo sendo criado como SAC-VOZ

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/482108](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/482108)

## 1. Identificação

- **ID/Ref:** WI-482108
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Identificamos um cenário estranho de casos sendo registrados como Origem WhatsApp Ativo, mas com toda a estrutura do caso com características de voz. Necessário verificar o que ocorreu para tal situação não ocorrer.

  


Solicito fazer um levantamento para verificarmos se existem outros caso ontem temos a Fila de Atendimento apontando para KON_SAC CC Estacio, e Tabulação relacionada a voz. Importante fazermos essa pesquisa de Jan/2025 até hoje.

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/f34d4d19-23d3-4c1f-87b5-9a825a36e385?fileName=image.png)  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/f727686b-1ec7-4795-9ad3-8f20b84df4fa?fileName=image.png)  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/057ac67e-3cc1-4a50-ab33-2d1f3d5c8eef?fileName=image.png)
