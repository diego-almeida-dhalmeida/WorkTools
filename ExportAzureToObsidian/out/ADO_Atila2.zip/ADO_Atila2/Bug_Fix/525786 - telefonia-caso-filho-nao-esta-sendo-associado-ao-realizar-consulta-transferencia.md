---
id: "WI-525786"
title: "[Telefonia] Caso filho não esta sendo associado ao realizar consulta/transferência para Retencao"
type: "Bug Fix"
state: "Active"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 08-2025-Relacionamento"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-08-19T21:51:40.267Z"
changed: "2025-09-12T13:53:35.923Z"
---
# WI-525786 - [Telefonia] Caso filho não esta sendo associado ao realizar consulta/transferência para Retencao

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/525786](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/525786)

## 1. Identificação

- **ID/Ref:** WI-525786
- **Tipo:** Bug Fix
- **Status:** Active


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Ao realizar transferência para outro operação o caso filho não esta sendo associado ao caso pai que originou a ligação 

  


  


**Caso pai 08154283    
**  
![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/448c2933-edde-4b44-b9e9-f96bcb795e4f?fileName=image.png)  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/735af568-5659-45e6-ba26-1cc31b70d703?fileName=image.png)  
  


**Caso filho 08154286**  
  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/14fa4277-580d-48b3-b06f-934ff30ecdb4?fileName=image.png)
