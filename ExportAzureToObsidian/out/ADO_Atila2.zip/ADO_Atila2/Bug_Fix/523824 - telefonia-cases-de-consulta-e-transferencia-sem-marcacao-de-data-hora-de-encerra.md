---
id: "WI-523824"
title: "[Telefonia] Cases de consulta e transferência sem marcação de data hora de encerramento"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-08-13T22:01:03.823Z"
changed: "2025-08-28T13:34:10.203Z"
---
# WI-523824 - [Telefonia] Cases de consulta e transferência sem marcação de data hora de encerramento

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523824](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523824)

## 1. Identificação

- **ID/Ref:** WI-523824
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Ausência de marcações de encerramento de atendimento nos casos que houveram consulta e nos que houveram transferência.  


  


**Cases:** 08153922 e 08153921 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/0e9d1e83-7d9c-42df-bfc0-3c67bd4ce28c?fileName=image.png)  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/7ed16d7f-52e6-47d5-bdeb-af685d9621bd?fileName=image.png)
