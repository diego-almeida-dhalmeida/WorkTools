---
id: "WI-417893"
title: "[WhatsApp] Inatividade não funcionando em alguns casos"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 01-2024-CoERelac"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-09-19T18:12:28.083Z"
changed: "2024-10-25T12:33:49.643Z"
---
# WI-417893 - [WhatsApp] Inatividade não funcionando em alguns casos

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417893](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417893)

## 1. Identificação

- **ID/Ref:** WI-417893
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Em alguns casos, a inatividade não está funcionando. O aluno não responde a mensagem e continua sem ser enviado para a inatividade. segue caso: **00883987**

**  
**

**Quando o aluno não responde uma mensagem, ele deve ser enviado para a inatividade seguindo o tempo registrado.**

**  
**

**exemplo:**

**![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/199eef43-0368-498a-be2e-ec4aa3c781ae?fileName=image.png)  
**
