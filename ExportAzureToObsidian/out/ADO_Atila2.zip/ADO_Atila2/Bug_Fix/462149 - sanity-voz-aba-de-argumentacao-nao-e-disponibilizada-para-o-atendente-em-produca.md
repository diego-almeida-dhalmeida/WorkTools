---
id: "WI-462149"
title: "[SANITY | VOZ] - Aba de Argumentação não é disponibilizada para o atendente em produção"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2025-Relacionamento"
assignedTo: "Lucas Morisson Loreto Machado"
created: "2025-02-21T19:25:48.847Z"
changed: "2025-03-12T02:04:15.167Z"
---
# WI-462149 - [SANITY | VOZ] - Aba de Argumentação não é disponibilizada para o atendente em produção

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/462149](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/462149)

## 1. Identificação

- **ID/Ref:** WI-462149
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

@Carlos Henrique da Costa Cavalcanti @Maria Virginia Matheus @Simone dos Santos Feliciano

  


A aba 'Argumentação' não está sendo disponibilizada na tela do atendente da telefonia no ambiente de produção. 

  


Testes pode ser feito utilizando o caminho 7>2>9 na URA utilizando um usuário da Elo. No momento o usuário da Miriam está disponível em PRD. 

  


Em UAT pode utilizar o usuário Ricardo Emilio. 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/902c3ad4-00b3-49c1-9566-f00a035adbad?fileName=image.png)  


  


No ambiente UAT a aba 'Argumentação' é disponibilizada na tela do atendente 

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/c87c76ee-5390-4b2d-a7d6-35241fc18e57?fileName=image.png)
