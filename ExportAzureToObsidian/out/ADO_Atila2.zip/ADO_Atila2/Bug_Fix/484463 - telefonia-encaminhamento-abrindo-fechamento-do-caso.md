---
id: "WI-484463"
title: "[Telefonia] - Encaminhamento abrindo fechamento do caso"
type: "Bug Fix"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Marcos Vinicius Almeida da Silva"
created: "2025-05-02T19:25:26.16Z"
changed: "2025-06-12T20:11:53.52Z"
---
# WI-484463 - [Telefonia] - Encaminhamento abrindo fechamento do caso

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/484463](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/484463)

## 1. Identificação

- **ID/Ref:** WI-484463
- **Tipo:** Bug Fix
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/0f12125e-7994-4307-becb-d1e349a4d36d?fileName=image.png)
