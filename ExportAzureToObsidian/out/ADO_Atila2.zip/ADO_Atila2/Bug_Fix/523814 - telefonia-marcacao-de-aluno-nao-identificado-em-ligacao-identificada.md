---
id: "WI-523814"
title: "[Telefonia] Marcação de aluno não identificado em ligação identificada"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-08-13T21:48:31.877Z"
changed: "2025-08-18T18:46:56.657Z"
---
# WI-523814 - [Telefonia] Marcação de aluno não identificado em ligação identificada

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523814](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523814)

## 1. Identificação

- **ID/Ref:** WI-523814
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Case 08153905 identificado na URA e transferido para o Atendimento Humano ficou com registro marcado como **Não Identificado** no case de atendimento.

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/b451f338-bda5-4348-a7c6-e9f62a22dd45?fileName=image.png)
