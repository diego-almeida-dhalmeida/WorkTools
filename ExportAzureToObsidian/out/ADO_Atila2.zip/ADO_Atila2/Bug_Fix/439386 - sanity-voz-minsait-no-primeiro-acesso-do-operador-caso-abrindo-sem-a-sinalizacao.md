---
id: "WI-439386"
title: "[SANITY | VOZ] Minsait - No primeiro acesso do operador, caso abrindo sem a sinalização de tabulação pendente"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2024-CoERelac-2 ªOndaTelefonia"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-11-29T19:22:35.373Z"
changed: "2025-02-19T16:51:05.12Z"
---
# WI-439386 - [SANITY | VOZ] Minsait - No primeiro acesso do operador, caso abrindo sem a sinalização de tabulação pendente

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/439386](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/439386)

## 1. Identificação

- **ID/Ref:** WI-439386
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

No primeiro acesso do operador, caso abrindo sem a sinalização de tabulação pendente. Depois que é dado um F5 ai a tela carrega corretamente: 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/2965427e-db37-48b1-bda6-0dbaf9c0a049?fileName=image.png)  


  
Segundo teste nas mesmas condições:   


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/6e7918e1-53e4-4448-9f5f-ab97295156a2?fileName=image.png)  
  


Depois do F5:  
  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/4d2ff322-4cde-43b3-9bcb-a3cf0eec8b0d?fileName=image.png)  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/afd7d0af-4ae9-4e1d-8102-e21407717abb?fileName=image.png)
