---
id: "WI-459254"
title: "[Telefonia] - Tabulação pendente ainda para casos que foram encaminhados - P1"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2025-Relacionamento"
assignedTo: "Diego Felipe"
created: "2025-02-13T21:18:16.163Z"
changed: "2025-03-21T14:47:07.5Z"
---
# WI-459254 - [Telefonia] - Tabulação pendente ainda para casos que foram encaminhados - P1

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/459254](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/459254)

## 1. Identificação

- **ID/Ref:** WI-459254
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

O caso 07750477 foi encaminhado e continuou com a "Tabulação Pendente" habilitada. Essa questão já foi tratada em UAT no card: [#443286](https://dev.azure.com/ArquiteturaEstacio/Atila%202.0/_workitems/edit/443286/). 

  


Caso testado junto com o time da Minsait: 07846221\. 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/bd0322bf-4d21-448a-b2e0-f44ac2dab6b3?fileName=image.png)
