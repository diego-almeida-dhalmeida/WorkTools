---
id: "WI-534898"
title: "[Telefonia] Transferencia Sac => Supervisor => Retenção nao esta abrindo caso filho para Retenção"
type: "Bug Fix"
state: "Active"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Reabastecimento-02-2025-Relacionamento"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-09-12T13:48:07.63Z"
changed: "2025-09-15T20:14:43.343Z"
---
# WI-534898 - [Telefonia] Transferencia Sac => Supervisor => Retenção nao esta abrindo caso filho para Retenção

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/534898](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/534898)

## 1. Identificação

- **ID/Ref:** WI-534898
- **Tipo:** Bug Fix
- **Status:** Active


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Quando seguido o fluxo de transferencia entre Sac => Supervisor => Retenção o caso nao esta sendo criado e popup em tela
