---
id: "WI-463147"
title: "[SANITY | VOZ] - Campo de \"Encaminhamento indevido\" não está aparecendo em PRD"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2025-Relacionamento"
assignedTo: "Renan Robson Lima Carneiro"
created: "2025-02-24T20:53:11.987Z"
changed: "2025-03-19T02:06:12.527Z"
---
# WI-463147 - [SANITY | VOZ] - Campo de "Encaminhamento indevido" não está aparecendo em PRD

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/463147](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/463147)

## 1. Identificação

- **ID/Ref:** WI-463147
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Bug está relacionado com a história: [#443289](https://dev.azure.com/ArquiteturaEstacio/Atila%202.0/_workitems/edit/443289/)

  


Para os testes, utilizar o usuário Marcos Macedo - marcos.dsantos.ter@estacio.br (Backoffice) 

  


Não estão aparecendo as informações de encaminhamento indevido no ambiente de Produção  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/00c37934-de76-4cfc-ba71-240920d4a35c?fileName=image.png)

  


No ambiente de UAT está aparecendo ok  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/8f46acd3-f5ec-47ea-9f3d-b3bad9597d43?fileName=image.png)
