---
id: "WI-410019"
title: "Ajuste no perfil Gestor – Aluno [Priorizado]"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 01-2024-CoERelac"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-08-26T21:58:30.457Z"
changed: "2024-10-18T02:27:39.713Z"
---
# WI-410019 - Ajuste no perfil Gestor – Aluno [Priorizado]

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/410019](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/410019)

## 1. Identificação

- **ID/Ref:** WI-410019
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Precisamos ajustar o **perfil Gestor – Aluno** , retirando as seguintes permissões de administrador, que estão atribuídas de forma equivocada ao perfil.   


  * Mudar perfil;
  * Criar usuário;
  * Desativar usuário.
