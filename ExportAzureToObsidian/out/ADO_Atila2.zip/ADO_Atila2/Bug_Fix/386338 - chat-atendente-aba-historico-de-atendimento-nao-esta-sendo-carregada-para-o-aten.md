---
id: "WI-386338"
title: "[Chat] ATENDENTE - Aba histórico de atendimento não está sendo carregada para o atendente"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-06-15T10:15:03.813Z"
changed: "2025-01-10T18:58:37.263Z"
---
# WI-386338 - [Chat] ATENDENTE - Aba histórico de atendimento não está sendo carregada para o atendente

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/386338](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/386338)

## 1. Identificação

- **ID/Ref:** WI-386338
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Aba histórico de atendimento não está sendo carregada para o atendente. Para o WhatsApp, a tela abre normalmente  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/dc0575f8-5d10-4a1c-a652-4e2c9b6be1da?fileName=image.png)
