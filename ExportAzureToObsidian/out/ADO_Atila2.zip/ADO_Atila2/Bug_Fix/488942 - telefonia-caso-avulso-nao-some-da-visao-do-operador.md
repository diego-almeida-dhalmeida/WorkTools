---
id: "WI-488942"
title: "[Telefonia] - Caso avulso não some da visão do operador"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 07-2025-Relacionamento"
assignedTo: "Marcos Vinicius Almeida da Silva"
created: "2025-05-15T20:14:17.98Z"
changed: "2025-07-31T19:49:07.003Z"
---
# WI-488942 - [Telefonia] - Caso avulso não some da visão do operador

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/488942](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/488942)

## 1. Identificação

- **ID/Ref:** WI-488942
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

No caso avulso, temos a tabulação e o fechamento sendo realizado, porém, o caso não sai da tela do operador. É necessário resolver esse problema para que a tela do operador não fique sobrecarregada. Esse problema tava a história relacionada ao Caso Avulso: [#485743](https://dev.azure.com/ArquiteturaEstacio/Atila%202.0/_workitems/edit/485743/)  
  


O problema está ocorrendo em UAT  
Acesso com "Atendente 1 SAC Konecta"  
  
![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/0fa73db8-108d-443f-ad8f-9b3c42e14560?fileName=image.png)
