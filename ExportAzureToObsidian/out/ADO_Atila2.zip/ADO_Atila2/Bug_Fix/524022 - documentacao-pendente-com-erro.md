---
id: "WI-524022"
title: "Documentação pendente - com erro"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Giovana Calderani Yaekashi"
created: "2025-08-14T13:47:22.803Z"
changed: "2025-09-03T13:07:55.027Z"
---
# WI-524022 - Documentação pendente - com erro

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/524022](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/524022)

## 1. Identificação

- **ID/Ref:** WI-524022
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

No caso de atendimento voz. Ao consultar as documentação pendente, o campo não abre.
