---
id: "WI-494296"
title: "[Telefonia - Sanity] - Modal de encerramento de Retenção com layout de SAC"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 08-2025-Relacionamento"
assignedTo: "Lucas Morisson Loreto Machado"
created: "2025-05-29T18:53:15.26Z"
changed: "2025-09-02T12:30:28.38Z"
---
# WI-494296 - [Telefonia - Sanity] - Modal de encerramento de Retenção com layout de SAC

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/494296](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/494296)

## 1. Identificação

- **ID/Ref:** WI-494296
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

O encerramento dos casos de retenção está exibindo uma tela errada. O correto é aparecer as opções de motivo de contato com as informações de motivo de retenção:  
  
Tela com problema referente ao caso 08150060 em UAT:  
  
![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/ac77ab1d-7597-4627-8346-42442c755457?fileName=image.png)  


  


O correto seria aparecer da seguinte forma:  
  
![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/894fd277-8c44-4532-92ba-426c23b468b9?fileName=image.png)
