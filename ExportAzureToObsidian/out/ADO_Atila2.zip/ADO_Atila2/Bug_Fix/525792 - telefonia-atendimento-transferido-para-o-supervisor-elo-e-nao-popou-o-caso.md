---
id: "WI-525792"
title: "[Telefonia] Atendimento transferido para o supervisor ELO e não \"popou\" o caso"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 08-2025-Relacionamento"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-08-19T21:54:56.96Z"
changed: "2025-08-28T13:33:49.97Z"
---
# WI-525792 - [Telefonia] Atendimento transferido para o supervisor ELO e não "popou" o caso

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/525792](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/525792)

## 1. Identificação

- **ID/Ref:** WI-525792
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Ao realizar transferência direta para o supervisor não o caso não "popou" na tela do supervisor  
  


Caso pai atendente ELO  
![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/78d2f37d-8d57-46f8-a9ed-281b0bd67d17?fileName=image.png)  


  


Caso supervisor sem popup  
![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/e902d10b-a240-4179-bb38-4a7a51e423b4?fileName=image.png)
