---
id: "WI-464715"
title: "[SANITY | VOZ] - Envio de email de produção não está funcionando"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2025-Relacionamento"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2025-02-28T15:08:51.113Z"
changed: "2025-03-12T13:16:05.887Z"
---
# WI-464715 - [SANITY | VOZ] - Envio de email de produção não está funcionando

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/464715](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/464715)

## 1. Identificação

- **ID/Ref:** WI-464715
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

O envio de e-mail da tarefa não está chegando para o aluno. 

  


Fizemos todas as verificações necessárias para realizar o envio, inclusive a validação dos endereços de e-mail no Salesforce. Mesmo assim as mensagens não chegam. Segue abaixo a evidência de envio.  

  


Os emails de destino foram o meu (carloshec@gmail.com) e o da Miriam (miriam.assuncao@yduqs.com.br) em cópia. 

  


Os testes foram feitos com o usuário: Renato Lima (renato.dlima.ter@estacio.br) 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/9e6879e0-a38f-4546-b872-d12de37f8b71?fileName=image.png)
