---
id: "WI-523330"
title: "[Telefonia] Tela de detalhamentos do caso em Histórico de atendimento \"mockada\""
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Guilherme Dionizio Brandao"
created: "2025-08-13T16:40:27.15Z"
changed: "2025-08-28T13:33:55.253Z"
---
# WI-523330 - [Telefonia] Tela de detalhamentos do caso em Histórico de atendimento "mockada"

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523330](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523330)

## 1. Identificação

- **ID/Ref:** WI-523330
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Na tela de caso, opção de Raio-X > Histórico de Atendimento a listagem de casos existentes para o aluno esta correta, porém ao clicar na Lupa para obter mais detalhes do caso as informações estão "mockadas", fixas para todos os cases. 

  


Segue prints abaixo: 

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/00e9eea6-b155-4616-9460-59eff5d70359?fileName=image.png)  
  


Case 08153864  
  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/d5ad92da-0a9a-44c4-9b0f-31ab40e4c42f?fileName=image.png)  


  


Case 08153767  
![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/87c23a55-af10-4e6c-a58c-8bdde3309e11?fileName=image.png)
