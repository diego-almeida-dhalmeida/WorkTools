---
id: "WI-523827"
title: "[Telefonia] Case com status fechado sem data hora de encerramento humano"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-08-13T22:14:42.223Z"
changed: "2025-08-28T13:34:01.647Z"
---
# WI-523827 - [Telefonia] Case com status fechado sem data hora de encerramento humano

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523827](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523827)

## 1. Identificação

- **ID/Ref:** WI-523827
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Case fechado sem marcação de data/hora fim de atendimento humano 

  


Case: 08153913 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/c4e7c775-2617-44d3-ab16-6f048ba49a60?fileName=image.png)  


  


  


  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/92481727-33c6-452e-a185-b6ce0450ab1c?fileName=image.png)
