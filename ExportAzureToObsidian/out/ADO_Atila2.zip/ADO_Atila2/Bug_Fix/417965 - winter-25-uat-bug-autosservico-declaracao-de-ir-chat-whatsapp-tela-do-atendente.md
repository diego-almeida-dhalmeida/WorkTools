---
id: "WI-417965"
title: "[Winter 25 - UAT] BUG - Autosserviço – Declaração de IR (Chat/WhatsApp/Tela do atendente)"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 01-2024-CoERelac"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-09-19T18:51:39.38Z"
changed: "2024-10-18T02:32:05.187Z"
---
# WI-417965 - [Winter 25 - UAT] BUG - Autosserviço – Declaração de IR (Chat/WhatsApp/Tela do atendente)

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417965](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417965)

## 1. Identificação

- **ID/Ref:** WI-417965
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Autosserviço – Declaração de IR – Chat, WhatsApp e Tela de atendimento (202305243577) => ERRO, apresenta os 5 últimos anos para seleção, mas retorna ERRO e não dispara o e-mail após selecionar o ano para envio da declaração do IR  


  


Tela do WhatsApp: 

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/65672780-7b33-48d8-a7f8-313bcdc2d400?fileName=image.png)  


  


Tela do Chat: 

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/266aca70-5670-47ce-a11d-a381c3a01654?fileName=image.png)  


  


Tela do Atendente: 

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/3d2fb864-556f-4a89-baad-81899c836264?fileName=image.png)  


  


Precisaremos do apoio das equipes técnicas para análise do problema:  


SIA - [@Carlos Henrique Abrantes](https://arquiteturaestacio.visualstudio.com/Atila%202.0/_workitems/edit/417862#)  


Mule - [@Wellington Assis de Paula](https://arquiteturaestacio.visualstudio.com/Atila%202.0/_workitems/edit/417862#)  


SF - [@Renan Robson Lima Carneiro](https://arquiteturaestacio.visualstudio.com/Atila%202.0/_workitems/edit/417862#)
