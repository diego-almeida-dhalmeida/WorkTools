---
id: "WI-463149"
title: "[SANITY | VOZ] - Supervisor não está visualizando o botão de \"Alterar proprietário\""
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2025-Relacionamento"
assignedTo: "Lucas Morisson Loreto Machado"
created: "2025-02-24T20:57:16.4Z"
changed: "2025-03-19T01:31:33.47Z"
---
# WI-463149 - [SANITY | VOZ] - Supervisor não está visualizando o botão de "Alterar proprietário"

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/463149](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/463149)

## 1. Identificação

- **ID/Ref:** WI-463149
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

A história de origem é a [#442939](https://dev.azure.com/ArquiteturaEstacio/Atila%202.0/_workitems/edit/442939/)

  


Teste realizado com o supervisor Ideméa de Jesus:  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/3a8f97aa-f2ab-471a-a5a6-a9d86052c5a2?fileName=image.png)  


  


Botão "Alterar proprietário" não aparece:  
  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/f647ac1e-a3c6-4d23-942a-6722b781771c?fileName=image.png)
