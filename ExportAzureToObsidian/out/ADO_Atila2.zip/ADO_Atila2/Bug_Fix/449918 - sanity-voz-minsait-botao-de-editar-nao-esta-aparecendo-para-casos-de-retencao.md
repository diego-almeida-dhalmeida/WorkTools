---
id: "WI-449918"
title: "[SANITY | VOZ] Minsait - Botão de editar não está aparecendo para casos de retenção"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 01-2025-Relacionamento"
assignedTo: "Lucas Morisson Loreto Machado"
created: "2025-01-17T00:36:11.49Z"
changed: "2025-02-19T16:49:36.703Z"
---
# WI-449918 - [SANITY | VOZ] Minsait - Botão de editar não está aparecendo para casos de retenção

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/449918](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/449918)

## 1. Identificação

- **ID/Ref:** WI-449918
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

O botão de editar não está aparecendo para casos de retenção. O botão deveria aparecer em baixo do título "Visualização do email".  


  
Usuário: israel.pinto.ter@estacio.br  
Casos: 00888188, 00887132, 00887084  
  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/6702ab2f-6beb-49e7-8b5f-f2c202961b6c?fileName=image.png)
