---
id: "WI-425265"
title: "[Winter 25 - PRD] Não apresenta a árvore de serviço para o aluno no Chat"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Miriam Assuncao Da Silva Candido"
created: "2024-10-12T16:07:03.907Z"
changed: "2024-12-03T13:41:55.58Z"
---
# WI-425265 - [Winter 25 - PRD] Não apresenta a árvore de serviço para o aluno no Chat

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/425265](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/425265)

## 1. Identificação

- **ID/Ref:** WI-425265
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Não apresenta a árvore de serviço para o aluno no Chat, tanto para matrícula ativa já existente no Salesforce quanto para matrícula inativa que não existe no SF, que seria carregada do SIA para o Salesforce por demanda durante o atendimento  

matrícula ativa-202306064731  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/d20bcd9a-8a2f-4c34-a94e-ca9a3cf735b9?fileName=image.png)  


matrícula inativa-201102074039-Estácio 

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/748a51bc-aa46-4997-820c-f7a64d8851a2?fileName=image.png)  
  


matricula-201609050029-Estácio 

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/c5f41786-db60-4d62-adfe-eadd7afa2e1c?fileName=image.png)  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/141e82ad-0b88-4228-b636-35a42bffe89b?fileName=image.png)
