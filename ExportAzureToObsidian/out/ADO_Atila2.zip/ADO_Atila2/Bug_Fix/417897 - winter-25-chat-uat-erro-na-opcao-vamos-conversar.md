---
id: "WI-417897"
title: "[Winter 25 - Chat UAT] Erro na opção vamos conversar!"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 01-2024-CoERelac"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-09-19T18:16:20.18Z"
changed: "2024-10-18T02:30:18.74Z"
---
# WI-417897 - [Winter 25 - Chat UAT] Erro na opção vamos conversar!

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417897](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417897)

## 1. Identificação

- **ID/Ref:** WI-417897
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/a1152c2a-98d5-4b09-b960-6886b6f32e9b?fileName=image.png)  


Ao falar que quer falar com um atendente, o chat da uma opção de Sim, vamos conversar. Nessa opção, ele deve ser direcionado novamente para o BOT, sem mensagem de OPS. 

  


comportamento esperado: 

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/7dcc14b2-ea3c-41bd-ac76-b004bde6c3cb?fileName=image.png)
