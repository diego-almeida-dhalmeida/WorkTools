---
id: "WI-463211"
title: "[Sanity | VOZ] - Status Backoffice não está mudando com com o fechamento do caso"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2025-Relacionamento"
assignedTo: "Renan Robson Lima Carneiro"
created: "2025-02-24T22:53:46.84Z"
changed: "2025-04-08T19:49:41.843Z"
---
# WI-463211 - [Sanity | VOZ] - Status Backoffice não está mudando com com o fechamento do caso

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/463211](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/463211)

## 1. Identificação

- **ID/Ref:** WI-463211
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Bug relacionado com a história: [#443290](https://dev.azure.com/ArquiteturaEstacio/Atila%202.0/_workitems/edit/443290/)  
  


Ao encerrar um caso do backoffice o Campo Status Backoffice não está atualizando para fechado de forma automática: 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/706faa26-c7cb-4ef6-b31c-6383e6f6110c?fileName=image.png)
