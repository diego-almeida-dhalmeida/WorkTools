---
id: "WI-441579"
title: "[SANITY | VOZ] EPS - Erro apontado no conector Avaya"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2024-CoERelac-2 ªOndaTelefonia"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-12-06T22:48:26.247Z"
changed: "2025-01-17T21:39:32.63Z"
---
# WI-441579 - [SANITY | VOZ] EPS - Erro apontado no conector Avaya

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/441579](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/441579)

## 1. Identificação

- **ID/Ref:** WI-441579
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Ao realizar a transferência para a pesquisa de satisfação, o conector Avaya apresenta mensagem de erro, porém a pesquisa é enviada para o aluno sem problemas (texto aparece no Conector Avaya) - tela erro 001 

_  
_

_Caminho da URA: *25_

_Matricula: 201908573317_

_Dia 06/12 as 11:04_

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/067626e1-5809-498e-8051-c1b31711449a?fileName=image.png)
