---
id: "WI-449920"
title: "[SANITY | VOZ] Minsait - Operadores Elo não conseguem realizar o fechamento do caso e recebem mensagem de erro."
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 01-2025-Relacionamento"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2025-01-17T01:04:51.057Z"
changed: "2025-02-18T21:40:02.703Z"
---
# WI-449920 - [SANITY | VOZ] Minsait - Operadores Elo não conseguem realizar o fechamento do caso e recebem mensagem de erro.

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/449920](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/449920)

## 1. Identificação

- **ID/Ref:** WI-449920
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Os operadores da Elo estão recebendo a seguinte mensagem de erro ao realizarem o fechamento de casos de retenção e SAC:  


**

Ocorreu um problema.

Não foi possível encontrar o registro que você está tentando acessar. Ele pode ter sido excluído por outro usuário ou pode ter sido um erro do sistema. Peça ajuda ao seu administrador. 

**

  
![undefined](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/b7a177f1-a57c-4a60-9918-c0f8417e91e1?fileName=image.png)
