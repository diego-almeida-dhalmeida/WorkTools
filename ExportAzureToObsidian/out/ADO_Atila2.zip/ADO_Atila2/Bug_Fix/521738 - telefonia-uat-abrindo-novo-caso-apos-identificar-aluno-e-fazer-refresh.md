---
id: "WI-521738"
title: "[Telefonia-UAT] Abrindo novo caso após identificar aluno e fazer refresh"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-08-08T20:51:20.1Z"
changed: "2025-08-15T21:02:35.877Z"
---
# WI-521738 - [Telefonia-UAT] Abrindo novo caso após identificar aluno e fazer refresh

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/521738](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/521738)

## 1. Identificação

- **ID/Ref:** WI-521738
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

@Marcos Vinicius Almeida da Silva @Adriano Meireles Santos  
  


Quando o operador tem um caso aberto em tela e executa um refresh F5 ao reabrir o CRM conector é criando um novo caso  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/d3ef1ea6-35cf-45d8-8148-0c13961121e0?fileName=image.png)  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/04454622-a35f-42a6-934d-889487b1ee75?fileName=image.png)
