---
id: "WI-456287"
title: "[SANITY | VOZ] Mutant - Pesquisa de Satisfação não registrada no caso (PRD)"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2025-02-05T21:49:49.517Z"
changed: "2025-03-13T19:49:39.873Z"
---
# WI-456287 - [SANITY | VOZ] Mutant - Pesquisa de Satisfação não registrada no caso (PRD)

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/456287](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/456287)

## 1. Identificação

- **ID/Ref:** WI-456287
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

@Carlos Henrique da Costa Cavalcanti @Maria Virginia Matheus @Simone dos Santos Feliciano

  


A resposta do aluno a Pesquisa de Satisfação, não foi registrada no caso ao final do atendimento com envio da pesquisa, em todos os testes respondemos '5' para a primeira pergunta e '1' para a segunda pergunta. 

Seguem evidencias de testes realizados no ambiente de produção   
  
  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/f48939f1-7887-4396-a7e6-e860f09ebe41?fileName=image.png)  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/7792fb72-7c10-4e6f-8c6e-6815701f4c2f?fileName=image.png)
