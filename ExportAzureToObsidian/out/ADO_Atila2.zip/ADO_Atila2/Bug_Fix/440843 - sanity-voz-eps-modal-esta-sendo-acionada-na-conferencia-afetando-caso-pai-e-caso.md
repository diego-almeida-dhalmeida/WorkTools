---
id: "WI-440843"
title: "[SANITY | VOZ] EPS - Modal está sendo acionada na conferencia afetando Caso Pai e Caso Filho"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 02-2025-Relacionamento"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-12-04T19:41:12.757Z"
changed: "2025-04-08T19:51:22.96Z"
---
# WI-440843 - [SANITY | VOZ] EPS - Modal está sendo acionada na conferencia afetando Caso Pai e Caso Filho

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/440843](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/440843)

## 1. Identificação

- **ID/Ref:** WI-440843
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

O Modal está sendo disparando com a conferência de chamada, no momento da seleção da VDN para conferência.   


  


No caso Pai:  
  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/63233ba1-3a6b-406c-a2e4-42a8534f92bb?fileName=image.png)  


  


No caso filho: 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/b12c6343-2281-4f2c-b6ac-b8afcf96d240?fileName=image.png)
