---
id: "WI-438729"
title: "[SANITY | VOZ] Minsait - Abertura do modal para transferencia da Pesquisa de Satisfação não está ok"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2024-CoERelac-2 ªOndaTelefonia"
assignedTo: "Diego Felipe"
created: "2024-11-28T13:52:58.75Z"
changed: "2025-01-09T19:56:37.71Z"
---
# WI-438729 - [SANITY | VOZ] Minsait - Abertura do modal para transferencia da Pesquisa de Satisfação não está ok

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/438729](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/438729)

## 1. Identificação

- **ID/Ref:** WI-438729
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Ligação quando é transferida para pesquisa de satisfação não exibe o Modal: 

  


Caso: 00886625  
Opção *83 => Já corrigido a situação de transferência do caso abrindo como fechado.

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/361aa19e-c213-4c2e-a13a-c84a414dd5d1?fileName=image.png)  


  
Modal não foi exibido: 

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/28b184fe-7a07-4b77-81b4-7198d006cca1?fileName=image.png)
