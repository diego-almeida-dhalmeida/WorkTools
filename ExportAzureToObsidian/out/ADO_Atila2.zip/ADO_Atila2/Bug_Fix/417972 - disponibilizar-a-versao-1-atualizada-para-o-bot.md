---
id: "WI-417972"
title: "Disponibilizar a Versão-1 atualizada para o BOT"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 01-2024-CoERelac"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-09-19T19:05:43.963Z"
changed: "2024-10-18T02:29:07.153Z"
---
# WI-417972 - Disponibilizar a Versão-1 atualizada para o BOT

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417972](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/417972)

## 1. Identificação

- **ID/Ref:** WI-417972
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Estamos com problema em relação a versão do bot, que precisa ser mantida a versão-1 ativa para do bot em produção. Percebemos que a cada novo deploy de produção, temos a versão 1 substituída por uma nova versão, e hoje estamos com a versão-4, pois precisamos que seja substituída pela versão-1 atualizada em produção.
