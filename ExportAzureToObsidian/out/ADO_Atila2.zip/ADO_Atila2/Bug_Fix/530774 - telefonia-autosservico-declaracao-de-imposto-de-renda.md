---
id: "WI-530774"
title: "[Telefonia] Autosserviço Declaração de Imposto de Renda"
type: "Bug Fix"
state: "Active"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Reabastecimento-02-2025-Relacionamento"
assignedTo: "Giovana Calderani Yaekashi"
created: "2025-09-01T22:04:21.097Z"
changed: "2025-09-15T20:14:43.343Z"
---
# WI-530774 - [Telefonia] Autosserviço Declaração de Imposto de Renda

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/530774](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/530774)

## 1. Identificação

- **ID/Ref:** WI-530774
- **Tipo:** Bug Fix
- **Status:** Active


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Solicitação de declaração de Imposto de renda apresenta sucesso na tela do operador mas não chega por e-mail  
  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/bfa5d4d3-8934-4758-b034-74ce00a3b4ed?fileName=image.png)
