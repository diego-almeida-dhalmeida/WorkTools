---
id: "WI-459227"
title: "[Telefonia] - SIA - Erro ao abrir declaração de matricula"
type: "Bug Fix"
state: "Active"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Miriam Assuncao Da Silva Candido"
created: "2025-02-13T20:33:55.657Z"
changed: "2025-09-01T16:52:51.063Z"
---
# WI-459227 - [Telefonia] - SIA - Erro ao abrir declaração de matricula

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/459227](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/459227)

## 1. Identificação

- **ID/Ref:** WI-459227
- **Tipo:** Bug Fix
- **Status:** Active


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Ao acessar o autosserviço Declaração de Matrícula tivemos retorno de erro.  


Caso: 07749522 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/46fe675e-cb84-45f1-a3ab-8e3c28105bbe?fileName=image.png)
