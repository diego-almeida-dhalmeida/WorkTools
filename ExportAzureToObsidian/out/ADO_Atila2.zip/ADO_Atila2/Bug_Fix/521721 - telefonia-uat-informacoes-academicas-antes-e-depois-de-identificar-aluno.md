---
id: "WI-521721"
title: "[Telefonia-UAT] Informações acadêmicas antes e depois de identificar aluno"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Lucas Machado Gullaci"
created: "2025-08-08T20:31:31.07Z"
changed: "2025-08-22T12:59:12.91Z"
---
# WI-521721 - [Telefonia-UAT] Informações acadêmicas antes e depois de identificar aluno

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/521721](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/521721)

## 1. Identificação

- **ID/Ref:** WI-521721
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

@Marcos Vinicius Almeida da Silva @Adriano Meireles Santos  
  


Entrando com atendimento de aluno 'não identificado', abriu a aba de informações 'Acadêmicas' e após identificar o aluno, não ocorreu o refresh na tela para exibir as informações 'Acadêmicas' do aluno que foi identificado (ficou com informações anteriores - não identificado - que não tem informações acadêmicas)  


  


OBS: após identificar o aluno precisa atualizar os dados acadêmicos, financeiros e Raio-X 

  


Problema ocorreu durante os testes que foram gravados na sexta (08/08/25) sala =>'[ SF Voz ] Teste Konecta' 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/649af120-185a-45c0-9cf7-551c8b154d8b?fileName=image.png)
