---
id: "WI-425266"
title: "[Winter 25 - PRD] Não apresenta a árvore da forma correta para o aluno no WhatsApp"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Miriam Assuncao Da Silva Candido"
created: "2024-10-12T16:18:51.98Z"
changed: "2024-12-03T13:50:43.08Z"
---
# WI-425266 - [Winter 25 - PRD] Não apresenta a árvore da forma correta para o aluno no WhatsApp

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/425266](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/425266)

## 1. Identificação

- **ID/Ref:** WI-425266
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Deu problema no doc pendente, na mesma conversa apresenta os docs pendentes, dá OPS e pede novamente a identificação do aluno  
  


matricula-200402051303 Estácio

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/03bf1551-0a6c-4e87-a9e2-c9336b1853fa?fileName=image.png)  


  


o mesmo aconteceu no HE, deu OPS após confirmação do e-mail, e pede novamente a identificação do aluno

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/d48bf1c3-6879-4f30-8d14-573781c355f8?fileName=image.png)
