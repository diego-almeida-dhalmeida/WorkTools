---
id: "WI-525462"
title: "[Telefonia] Encaminhamento atualizando proprietário do caso pai"
type: "Bug Fix"
state: "Active"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-08-19T14:39:31.443Z"
changed: "2025-09-12T13:53:19.23Z"
---
# WI-525462 - [Telefonia] Encaminhamento atualizando proprietário do caso pai

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/525462](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/525462)

## 1. Identificação

- **ID/Ref:** WI-525462
- **Tipo:** Bug Fix
- **Status:** Active


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Ao encaminhar atendimento para o backoffice o caso pai o proprietário esta sendo atualizado como atendente de Backoffice  
  


Caso 08154153  
  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/aaea7f65-64d7-49a8-ae88-eff2df96c071?fileName=image.png)
