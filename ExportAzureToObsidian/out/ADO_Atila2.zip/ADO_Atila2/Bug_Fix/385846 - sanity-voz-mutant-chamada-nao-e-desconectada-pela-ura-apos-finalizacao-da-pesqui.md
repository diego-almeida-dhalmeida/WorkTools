---
id: "WI-385846"
title: "[SANITY | VOZ] Mutant - Chamada não é desconectada pela URA após finalização da pesquisa"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2024-CoERelac-2 ªOndaTelefonia"
assignedTo: "Marcos Vinicius Almeida da Silva"
created: "2024-06-13T21:26:02.51Z"
changed: "2025-01-09T19:56:37.71Z"
---
# WI-385846 - [SANITY | VOZ] Mutant - Chamada não é desconectada pela URA após finalização da pesquisa

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/385846](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/385846)

## 1. Identificação

- **ID/Ref:** WI-385846
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Chamada não é desconectada pela URA após finalização da pesquisa.  


**_  
Copied from Repro Steps when changed from Bug to Bug Fix_**  


**13/06**

Início do dia: após transbordo, ligação ficava no mudo  
Final do dia: Chamada não é desconectada pela URA após finalização da pesquisa
