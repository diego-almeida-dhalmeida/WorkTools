---
id: "WI-523818"
title: "[Telefonia] Tempos de atendimento negativos e registro de fechamento de atendimento da URA pós ATH"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-08-13T21:51:38.43Z"
changed: "2025-08-28T13:33:02.447Z"
---
# WI-523818 - [Telefonia] Tempos de atendimento negativos e registro de fechamento de atendimento da URA pós ATH

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523818](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/523818)

## 1. Identificação

- **ID/Ref:** WI-523818
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Marcação de fechamento de atendimento da URA pós inicio de atendimento humano. Tempos de atendimento também ficaram negativos.  


  


**Case:  08153905  
  
**

**![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/5939ff68-9a04-4a89-9a62-aade103610ac?fileName=image.png)  
**
