---
id: "WI-439405"
title: "[SANITY | VOZ] Minsait - Remover do operador (Atendente Voz - Aluno) o campo \"Caso Pai\" do layout"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 04-2024-CoERelac-2 ªOndaTelefonia"
assignedTo: "Carlos Henrique da Costa Cavalcanti"
created: "2024-11-29T20:00:23.87Z"
changed: "2025-03-07T18:11:00.767Z"
---
# WI-439405 - [SANITY | VOZ] Minsait - Remover do operador (Atendente Voz - Aluno) o campo "Caso Pai" do layout

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/439405](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/439405)

## 1. Identificação

- **ID/Ref:** WI-439405
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Ao se clicar no caso pai, a referência abre com erro.  


  


No momento, remover do operador (Atendente Voz - Aluno) o campo "Caso Pai" do layout. 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/d8d67217-4589-4d08-9db7-86190b3eb01c?fileName=image.png)
