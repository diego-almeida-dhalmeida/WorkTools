---
id: "WI-423529"
title: "[Winter 25-UAT] - Problema na última API da Negociação de Débitos (Chat/WhatsApp)"
type: "Bug Fix"
state: "Closed"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 02-2024-CoERelac"
assignedTo: "Rodney Lanzoni Fagundes"
created: "2024-10-07T16:21:46.163Z"
changed: "2024-11-05T20:18:02.79Z"
---
# WI-423529 - [Winter 25-UAT] - Problema na última API da Negociação de Débitos (Chat/WhatsApp)

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/423529](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/423529)

## 1. Identificação

- **ID/Ref:** WI-423529
- **Tipo:** Bug Fix
- **Status:** Closed


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Autosserviço – Negociação de Débitos – Chat e WhatsApp (202203366531)=> ERRO, passa pela maioria das 8 APIs vinculadas a negociação, onde apresentar as dívidas do aluno e apresentar as propostas para negociação ao aluno, após todo processo da negociação feita pela seleção das opções pelo aluno, quando vai confirmar que é o próprio que está fazendo a negociação através da confirmação do dia/mês de seu nascimento, retorna OPS conforme tela abaixo  
  
  


  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/536a2f7d-46bd-493b-8807-0205553739cf?fileName=image.png)
