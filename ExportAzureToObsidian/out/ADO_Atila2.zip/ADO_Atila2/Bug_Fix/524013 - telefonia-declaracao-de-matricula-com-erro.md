---
id: "WI-524013"
title: "[Telefonia] - Declaração de matricula - com erro"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Giovana Calderani Yaekashi"
created: "2025-08-14T13:32:26.87Z"
changed: "2025-09-02T17:43:00.37Z"
---
# WI-524013 - [Telefonia] - Declaração de matricula - com erro

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/524013](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/524013)

## 1. Identificação

- **ID/Ref:** WI-524013
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Na tela de caso. Em declaração de matriculá está ahavendo um erro na tela que não permite visualizar as informações de matricula do aluno.
