---
id: "WI-525150"
title: "[Telefonia] Caso filho sendo criado em transferência da URA para o Humano"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 08-2025-Relacionamento"
assignedTo: "Diego Henrique Nascimento de Almeida"
created: "2025-08-18T19:02:59.677Z"
changed: "2025-08-28T13:34:13.083Z"
---
# WI-525150 - [Telefonia] Caso filho sendo criado em transferência da URA para o Humano

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/525150](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/525150)

## 1. Identificação

- **ID/Ref:** WI-525150
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Caso filho sendo criado em todas as transferências da URA para o Humano. 

  


Case: 08154064 com sinalização de transbordo para o humano = Sim

![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/3bacb986-df67-4958-b734-f9f26ee6a390?fileName=image.png)  


  


  


E possui dois casos filhos relacionados, um de transferência da URA para o Atendente (Incorreto) e o outro do Atendente para o Supervisor (Correto). 

  


![Image](https://dev.azure.com/ArquiteturaEstacio/db028a6d-95bf-4de3-8a6d-3b5bdaa4f8d7/_apis/wit/attachments/354a6c0f-6785-42f8-8cd8-58bf52e73ce3?fileName=image.png)
