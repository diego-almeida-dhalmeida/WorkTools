---
id: "WI-493196"
title: "[Telefonia] - Bugs de caso avulso para Telefonia"
type: "Bug Fix"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: "Lucas Machado Gullaci"
created: "2025-05-27T18:45:35.13Z"
changed: "2025-08-12T13:47:46.517Z"
---
# WI-493196 - [Telefonia] - Bugs de caso avulso para Telefonia

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/493196](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/493196)

## 1. Identificação

- **ID/Ref:** WI-493196
- **Tipo:** Bug Fix
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Esse bugfix trata dos 3 erros encontrados pelo Carlos Henrique durante a validação do 485743  
  


  * Problemas na exibição das informações Acadêmicas e Financeiras e Raio-X
  * O perfil que precisa visualizar o caso avulso é somente o Atendente-Voz Aluno. Estamos com o perfil Atendente - Aluno acessando o caso avulso.
  * Não está fechando o caso para a opção de: Atendimento Retenção
