---
id: "WI-533045"
title: "Regras de validação - Solução Serviço"
type: "Tech Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 08-2025-Relacionamento"
assignedTo: ""
created: "2025-09-08T18:30:20.19Z"
changed: "2025-09-09T13:55:01.62Z"
---
# WI-533045 - Regras de validação - Solução Serviço

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/533045](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/533045)

## 1. Identificação

- **ID/Ref:** WI-533045
- **Tipo:** Tech Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

* Tela de encaminhamento 
  * Designação das filas de atendimento do registro Attendance__c (?)


## 9. Descrição (Abaixo vem do Azure DevOps)

_Sem descrição no ADO._
