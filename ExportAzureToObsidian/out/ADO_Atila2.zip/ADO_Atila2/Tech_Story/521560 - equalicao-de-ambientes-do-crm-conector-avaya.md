---
id: "WI-521560"
title: "Equalicao de ambientes do CRM Conector AVAYA"
type: "Tech Story"
state: "Active"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 08-2025-Relacionamento"
assignedTo: "Guilherme Dionizio Brandao"
created: "2025-08-08T15:03:56.76Z"
changed: "2025-09-12T18:56:04.16Z"
---
# WI-521560 - Equalicao de ambientes do CRM Conector AVAYA

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/521560](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/521560)

## 1. Identificação

- **ID/Ref:** WI-521560
- **Tipo:** Tech Story
- **Status:** Active


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

PAcote do flosum atualizado e deploy pronto pra uat3


## 9. Descrição (Abaixo vem do Azure DevOps)

Fazer backpromotion das alteracoes de UAT3
