---
id: "WI-533070"
title: "LWC Encaminhamento"
type: "Tech Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 08-2025-Relacionamento"
assignedTo: ""
created: "2025-09-08T18:46:45.647Z"
changed: "2025-09-09T13:55:01.62Z"
---
# WI-533070 - LWC Encaminhamento

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/533070](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/533070)

## 1. Identificação

- **ID/Ref:** WI-533070
- **Tipo:** Tech Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

* Validação, a partir dos valores informados nos campos de tabulação do time de SAC, quais os serviços associados à respectiva tabulação;
  * Campo look up para objeto custom "Services__c" com os registros associados à tabulação associado


## 9. Descrição (Abaixo vem do Azure DevOps)

Tela anterior ao encaminhamento do caso contendo os campos para a tabulação do atendimento do SAC e seleção do serviço de interesse do solicitante.
