---
id: "WI-508718"
title: "[Relacionamento] - Redução de Storage - objeto Mensageria"
type: "Tech Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 2025"
assignedTo: "Eugenio Souza Veras"
created: "2025-07-09T12:54:24.027Z"
changed: "2025-08-08T14:59:19.553Z"
---
# WI-508718 - [Relacionamento] - Redução de Storage: objeto Mensageria

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/508718](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/508718)

## 1. Identificação

- **ID/Ref:** WI-508718
- **Tipo:** Tech Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

- 


## 9. Descrição (Abaixo vem do Azure DevOps)

Conforme alinhado em Tech Sync de 08/07/25 e indicado no slide 08 do anexo "Apresentacao - DataStorage 072025", esse card foi criado devido à necessidade de tratar o objeto Mensageria para redução do Storage.
