---
id: "WI-533072"
title: "LWC Dados do caso"
type: "Tech Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 08-2025-Relacionamento"
assignedTo: ""
created: "2025-09-08T18:51:18.51Z"
changed: "2025-09-09T13:55:01.62Z"
---
# WI-533072 - LWC Dados do caso

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/533072](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/533072)

## 1. Identificação

- **ID/Ref:** WI-533072
- **Tipo:** Tech Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

Componente específico para record page no objeto custom Attendance__c consolidando os dados do caso que originou o registro subsequente, evitando a criação dos campos novamente no segundo objeto.  


  


-> Seção "Dados do caso"  


    Descrição - traz o texto escrito pelo atendente/operador sobre a solicitação do aluno  


      


-> Seção "Dados do solicitante"  


    Nome do solicitante  


    Telefone - fixo  


    E-mail  


    CPF  


    Telefone Celular  


    Telefone Principal  


  


-> Seção "Dados do curso"  


    Matrícula  


    Cód. Curso  


    Curso  


    Forma de Ingresso  


    Campus  


    Modalidade


## 9. Descrição (Abaixo vem do Azure DevOps)

Seção dentro do registro de atendimento trazendo as informações já preenchidas na tela do caso relacionado.
