---
id: "WI-533055"
title: "Flows - Solução Serviço"
type: "Tech Story"
state: "New"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0"
assignedTo: ""
created: "2025-09-08T18:32:08.843Z"
changed: "2025-09-09T14:15:42.127Z"
---
# WI-533055 - Flows - Solução Serviço

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/533055](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/533055)

## 1. Identificação

- **ID/Ref:** WI-533055
- **Tipo:** Tech Story
- **Status:** New


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

* Tabulação 
  * Encaminhamento 
  * Encerramento de caso


## 9. Descrição (Abaixo vem do Azure DevOps)

História técnica para criar as automações de fluxos para tabulação, encaminhamento e encerramento dos casos com base no relacionamento dos registros de atendimento (Attendance__c).
