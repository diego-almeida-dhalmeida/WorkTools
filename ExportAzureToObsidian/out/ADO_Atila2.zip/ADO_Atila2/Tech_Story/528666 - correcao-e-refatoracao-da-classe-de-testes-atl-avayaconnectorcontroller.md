---
id: "WI-528666"
title: "Correcao e refatoracao da Classe de Testes ATL_AvayaConnectorController"
type: "Tech Story"
state: "Resolved"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Reabastecimento-01-2025-Relacionamento"
assignedTo: "Guilherme Dionizio Brandao"
created: "2025-08-27T13:51:26.833Z"
changed: "2025-09-11T13:36:17.453Z"
---
# WI-528666 - Correcao e refatoracao da Classe de Testes ATL_AvayaConnectorController

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/528666](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/528666)

## 1. Identificação

- **ID/Ref:** WI-528666
- **Tipo:** Tech Story
- **Status:** Resolved


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

Executados os testes com 80%


## 9. Descrição (Abaixo vem do Azure DevOps)

ATL_AvayaConnectorController
