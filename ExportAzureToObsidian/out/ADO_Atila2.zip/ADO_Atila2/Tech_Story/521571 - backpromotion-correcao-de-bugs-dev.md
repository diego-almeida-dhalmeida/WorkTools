---
id: "WI-521571"
title: "Backpromotion correção de bugs dev"
type: "Tech Story"
state: "Active"
area: "Atila 2.0\COE RELACIONAMENTO"
iteration: "Atila 2.0\Sprint 08-2025-Relacionamento"
assignedTo: "Lucas Machado Gullaci"
created: "2025-08-08T16:11:14.9Z"
changed: "2025-09-08T13:45:35.153Z"
---
# WI-521571 - Backpromotion correção de bugs dev

**Link ADO:** [https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/521571](https://dev.azure.com/arquiteturaestacio/Atila%202.0/_workitems/edit/521571)

## 1. Identificação

- **ID/Ref:** WI-521571
- **Tipo:** Tech Story
- **Status:** Active


## 2. Contexto
- **Objetivo do Caso de Uso:** 
- **Descrição Resumida:** 


## 3. Fluxo Principal
1. 
2. 
3. 


## 4. Fluxos Alternativos
- 


## 5. Fluxos de Exceção
- 


## 6. Regras de Negócio
- 


## 7. Requisitos Não Funcionais
- 


## 8. Métricas e Critérios de Aceite

Estar com as prs abertas e validadas para uat


## 9. Descrição (Abaixo vem do Azure DevOps)

Realizar o backpromotion para dev das alterações dos cards 493196 e 496466
